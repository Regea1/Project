//#include <Windows.h>
//#include "Page_Home.h"
//#include "Page_Search.h"
//
//using namespace RealEstateProject;
////Page_Home^ Page_Home;
//class Page_Home;
//Page_Home ^ zome;
//
////...
//System::Void Page_Search::Back2Page_Home_Click(System::Object^ sender, System::EventArgs^ e){
////void Page_Search::buttonBack_Click(System::Object^ sender, System::EventArgs^ e) {
//    this->Hide();
//    zome->Show();
//}
//
//void CurrentForm::setPreviousForm(PreviousForm^ prev) {
//    previousForm = prev;
//}