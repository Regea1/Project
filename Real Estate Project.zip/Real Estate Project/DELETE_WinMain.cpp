//#include <Windows.h>
//#include <tchar.h>
//#include "Page_Home.h"
//
//using namespace RealEstateProject; //project name
//
////int APIENTRY _tWinMain(_In_ HINSTANCE hInstance,
////    _In_opt_ HINSTANCE hPrevInstance,
////    _In_ LPTSTR    lpCmdLine,
////    _In_ int       nCmdShow)
//int APIENTRY WinMain(HINSTANCE hInstance,
//        HINSTANCE hPrevInstance,
//        LPSTR lpCmdLine,
//        int nCmdShow)
//{
//    UNREFERENCED_PARAMETER(hPrevInstance);
//    UNREFERENCED_PARAMETER(lpCmdLine);
//
//    // Initialize the Windows Forms application
//    System::Windows::Forms::Application::EnableVisualStyles();
//    System::Windows::Forms::Application::SetCompatibleTextRenderingDefault(false);
//
//    // Create and show the main form
//    //Page_Home^ form = gcnew Page_Home();
//    System::Windows::Forms::Application::Run(gcnew Page_Home());
//
//    return 0;
//}
//
//
////#include "Page_Home.h"
////#include <Windows.h>
////
////using namespace RealEstateProject; //project name
////
////int WINAPI main(HINSTANCE, HINSTANCE, LPSTR, int) {
////    Application::EnableVisualStyles();
////    Application::SetCompatibleTextRenderingDefault(false);
////
////    Application::Run(gcnew Page_Home());
////
////    return 0;
////}
//
